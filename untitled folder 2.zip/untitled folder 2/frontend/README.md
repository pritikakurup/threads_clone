# Threads UI Clone Youtube Tutorial

### Built With React and Chakra UI

# [Tutorial](https://youtu.be/TW7wltm4gD8)

# [App Demo](https://threads-clone-yt.vercel.app/)

![Screenshot of App](https://i.ibb.co/bsJ6jf6/Screenshot-5.png)
